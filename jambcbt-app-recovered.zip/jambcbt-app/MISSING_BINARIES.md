# Missing binary files

This project was recovered from a `git diff` patch (not `git diff --binary`),
so binary files could not be reconstructed — only their paths were recorded.
The following files exist as **empty 0-byte placeholders** and need to be
replaced with real content before the app will build/run correctly:

## App icons
- `assets/icon.png` (source icon used by flutter_launcher_icons)
- `android/app/src/main/res/mipmap-{hdpi,mdpi,xhdpi,xxhdpi,xxxhdpi}/ic_launcher.png`
- `android/app/src/main/res/drawable-{hdpi,mdpi,xhdpi,xxhdpi,xxxhdpi}/ic_launcher_foreground.png`
- `ios/Runner/Assets.xcassets/AppIcon.appiconset/Icon-App-*.png` (all sizes)

  → Fix: put your real `icon.png` at `assets/icon.png`, then run:
  ```
  flutter pub get
  flutter pub run flutter_launcher_icons
  ```
  This regenerates every Android/iOS icon size automatically.

## Sound effects
- `assets/sounds/applause.wav`
- `assets/sounds/complete.wav`
- `assets/sounds/correct.wav`
- `assets/sounds/fail.wav`
- `assets/sounds/wrong.wav`

  → Fix: replace with your original (or new royalty-free) sound files,
  keeping the same filenames.

## Gradle wrapper jar
- `android/gradle/wrapper/gradle-wrapper.jar`

  → Fix: regenerate it — from the `android/` folder run:
  ```
  gradle wrapper
  ```
  (or copy `gradle-wrapper.jar` from any recent Flutter project template).

Everything else in this archive (all Dart code, JSON question banks,
Gradle/Manifest configs, CI workflows, docs, Python generator scripts)
was recovered in full from the patch as plain text.
